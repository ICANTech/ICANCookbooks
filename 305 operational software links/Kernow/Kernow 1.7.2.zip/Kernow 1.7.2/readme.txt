
Start Kernow by using the Kernow.bat or Kernow.exe files (Windows), or Kernow.sh for OSX, or just by double-clicking the jar file.

*Older versions of OSX may require the Java 1.5 version of Kernow, please visit the Kernow website for more information.

If you use Saxon-PE / Saxon-EE you will need to start Kernow using Kernow.bat or Kernow.sh to ensure the classpath is setup correctly. Put your license file in this directory, alongside this readme.

Any problems, queries or suggestions, let me know 

andrew.j.welch@gmail.com