
**Saxon PE and EE only, "reflexive" extensions are not available in Saxon HE. 

Place extension jars in here

Run Kernow using either the kernow.bat kernow.sh and the extensions will be available, otherwise you will need to manually set up your classpath 