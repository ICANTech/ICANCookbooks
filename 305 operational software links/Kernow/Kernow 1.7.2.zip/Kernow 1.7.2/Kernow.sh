java -splash:lib/splash.gif -Xmx256m -cp ".:kernow.jar:saxon9ee.jar:saxon9he.jar:xercesImpl.jar:xml-apis.jar:serializer.jar:resolver.jar:org.eclipse.wst.xml.xpath2.processor_1.1.0.jar:icu4j.jar:cupv10k-runtime.jar:rsyntaxtextarea.jar:autocomplete.jar:swing-layout-1.0.4.jar:ant.jar:ant-launcher.jar" net.sf.kernow.GUI












